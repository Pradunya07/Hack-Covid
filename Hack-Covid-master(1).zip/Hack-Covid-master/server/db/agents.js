/**
 * Copyright 2017 Intel Corporation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ----------------------------------------------------------------------------
 */
'use strict'

const r = require('rethinkdb')

const db = require('./')

const hasCurrentBlock = currentBlock => obj => {
  return r.and(
    obj('startBlockNum').le(currentBlock),
    obj('endBlockNum').gt(currentBlock)
  )
}

const getAttribute = attr => obj => obj(attr)
const getRecordId = getAttribute('recordId')
const getPublicKey = getAttribute('publicKey')
const getName = getAttribute('name')
const getReporters = getAttribute('reporters')
const getAuthorized = getAttribute('authorized')
const getType = getAttribute('type')

const hasPublicKey = key => obj => {
  return r.eq(
    key,
    getPublicKey(obj)
  )
}

const getAssociatedAgentId = role => record => record(role).nth(-1)('agentId')
const getOwnerId = getAssociatedAgentId('owners')
const getCustodianId = getAssociatedAgentId('custodians')

const isAssociatedWithRecord = association => agent => record => {
  return r.eq(
    association(record),
    getPublicKey(agent)
  )
}

const isRecordOwner = isAssociatedWithRecord(getOwnerId)
const isRecordCustodian = isAssociatedWithRecord(getCustodianId)

const isReporter = agent => property => {
  return getReporters(property)
    .filter(hasPublicKey(getPublicKey(agent)))
    .do(seq => r.branch(
      seq.isEmpty(),
      false,
      getAuthorized(seq.nth(0))
    ))
}

const getTable = (tableName, block) =>
      r.table(tableName).filter(hasCurrentBlock(block))

const listQuery = filterQuery => block => {
  return getTable('agents', block)
    .filter(filterQuery)
    .map(agent => r.expr({
      'name': getName(agent),
      'key': getPublicKey(agent),
      'type': getType(agent),
      'owns': getTable('records', block)
        .filter(isRecordOwner(agent))
        .map(getRecordId)
        .distinct(),
      'custodian': getTable('records', block)
        .filter(isRecordCustodian(agent))
        .map(getRecordId)
        .distinct(),
      'reports': getTable('properties', block)
        .filter(isReporter(agent))
        .map(getRecordId)
        .distinct()
    })).coerceTo('array')
}

const fetchQuery = (publicKey, auth) => block => {
  return getTable('agents', block)
    .filter(hasPublicKey(publicKey))
    .pluck('name', 'publicKey', 'type')
    .nth(0)
    .do(
      agent => {
        return r.branch(
          agent('type').eq('Manufacturer'),
          r.branch(
            auth,
            agent.merge(
              manufacturers(publicKey)),
            agent),
          r.branch(
            auth,
            agent.merge(
              certifiers(publicKey)),
            agent)
        )
      })
}

const fetchUser = publicKey => {
  return r.table('users')
    .filter(hasPublicKey(publicKey))
    .pluck('username', 'email', 'encryptedKey')
    .nth(0)
}

const fetchManufacturer = publicKey => {
  return r.table('manufacturers')
    .filter(hasPublicKey(publicKey))
    .pluck('pincode', 'gst_no', 'contact_no')
    .nth(0)
}

const fetchCertifier = publicKey => {
  return r.table('certifiers')
    .filter(hasPublicKey(publicKey))
    .pluck('pincode', 'address')
    .nth(0)
}

const manufacturers = publicKey => fetchManufacturer(publicKey).merge(fetchUser(publicKey))

const certifiers = publicKey => fetchCertifier(publicKey).merge(fetchUser(publicKey))

const list = filterQuery => db.queryWithCurrentBlock(listQuery(filterQuery))

const fetch = (publicKey, auth) =>
      db.queryWithCurrentBlock(fetchQuery(publicKey, auth))

module.exports = {
  list,
  fetch
}
